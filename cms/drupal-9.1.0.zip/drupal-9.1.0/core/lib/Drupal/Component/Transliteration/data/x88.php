<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ci', 'xiang', 'she', 'luo', 'qin', 'ying', 'chai', 'li', 'zei', 'xuan', 'lian', 'zhu', 'ze', 'xie', 'mang', 'xie',
  0x10 => 'qi', 'rong', 'jian', 'meng', 'hao', 'ru', 'huo', 'zhuo', 'jie', 'pin', 'he', 'mie', 'fan', 'lei', 'jie', 'la',
  0x20 => 'min', 'li', 'chun', 'li', 'qiu', 'nie', 'lu', 'du', 'xiao', 'zhu', 'long', 'li', 'long', 'feng', 'ye', 'beng',
  0x30 => 'nang', 'gu', 'juan', 'ying', 'shu', 'xi', 'can', 'qu', 'quan', 'du', 'can', 'man', 'qu', 'jie', 'zhu', 'zhuo',
  0x40 => 'xue', 'huang', 'niu', 'pei', 'nu', 'xin', 'zhong', 'mai', 'er', 'ka', 'mie', 'xi', 'xing', 'yan', 'kan', 'yuan',
  0x50 => 'qu', 'ling', 'xuan', 'shu', 'xian', 'tong', 'xiang', 'jie', 'xian', 'ya', 'hu', 'wei', 'dao', 'chong', 'wei', 'dao',
  0x60 => 'zhun', 'heng', 'qu', 'yi', 'yi', 'bu', 'gan', 'yu', 'biao', 'cha', 'yi', 'shan', 'chen', 'fu', 'gun', 'fen',
  0x70 => 'shuai', 'jie', 'na', 'zhong', 'dan', 'yi', 'zhong', 'zhong', 'jie', 'zhi', 'xie', 'ran', 'zhi', 'ren', 'qin', 'jin',
  0x80 => 'jun', 'yuan', 'mei', 'chai', 'ao', 'niao', 'hui', 'ran', 'jia', 'tuo', 'ling', 'dai', 'bao', 'pao', 'yao', 'zuo',
  0x90 => 'bi', 'shao', 'tan', 'ju', 'he', 'xue', 'xiu', 'zhen', 'yi', 'pa', 'bo', 'di', 'wa', 'fu', 'gun', 'zhi',
  0xA0 => 'zhi', 'ran', 'pan', 'yi', 'mao', 'tuo', 'na', 'gou', 'xuan', 'zhe', 'qu', 'bei', 'gun', 'xi', 'ni', 'bo',
  0xB0 => 'bo', 'fu', 'chi', 'chi', 'ku', 'ren', 'jiang', 'jia', 'jian', 'bo', 'jie', 'er', 'ge', 'ru', 'zhu', 'gui',
  0xC0 => 'yin', 'cai', 'lie', 'ka', 'xing', 'zhuang', 'dang', 'xu', 'kun', 'ken', 'niao', 'shu', 'jia', 'kun', 'cheng', 'li',
  0xD0 => 'juan', 'shen', 'pou', 'ge', 'yi', 'yu', 'zhen', 'liu', 'qiu', 'qun', 'ji', 'yi', 'bu', 'zhuang', 'shui', 'sha',
  0xE0 => 'qun', 'li', 'lian', 'lian', 'ku', 'jian', 'fou', 'chan', 'bi', 'kun', 'tao', 'yuan', 'ling', 'chi', 'chang', 'chou',
  0xF0 => 'duo', 'biao', 'liang', 'shang', 'pei', 'pei', 'fei', 'yuan', 'luo', 'guo', 'yan', 'du', 'ti', 'zhi', 'ju', 'yi',
];
